package com.example.epi_app

data class Team(val nombre: String, val cargo: String, val imagen: Int, val descripcion: String)