package com.example.epi_app.model.local

class Tienda(val imagenProducto:Int, val nombreProducto:String, val precioProducto:Int ) {
}