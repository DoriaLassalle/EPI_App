package com.example.epi_app.model.local

class EpiPony(val imageponyFace:Int,val  nomPony: String, val desc:String, val fullimage:Int )