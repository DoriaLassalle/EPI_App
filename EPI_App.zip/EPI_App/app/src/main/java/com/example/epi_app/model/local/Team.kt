package com.example.epi_app.model.local

data class Team(val nombre: String, val cargo: String, val imagen: Int, val descripcion: String)